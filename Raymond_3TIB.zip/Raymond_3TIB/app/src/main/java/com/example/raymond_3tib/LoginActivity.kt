package com.example.raymond_3tib

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.raymond_3tib.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        val tblLogin : Button =findViewById(R.id.btnLogin)
//        val usrnmData : EditText =findViewById(R.id.edtUsername)
//        val passData : EditText =findViewById(R.id.edtpassword)

        binding.btnLogin.setOnClickListener {
            val user=binding.edtUsername.text
            val pass=binding.edtpassword.text
            Log.e("Hasil","Username: $user Password: $pass")

            Toast.makeText(this, "Username: $user \nPassword: $pass", Toast.LENGTH_LONG).show()
        }
    }
}